"use client"

import { useEffect } from "react"
import { useRouter, usePathname } from "next/navigation"
import { AuthProvider, useAuth } from "@/lib/auth/auth-context"

function AuthGuard({ children }: { children: React.ReactNode }) {
  const { session, loading } = useAuth()
  const router = useRouter()
  const pathname = usePathname()

  const isLoginPage = pathname === "/studio/login"

  useEffect(() => {
    if (loading) return
    if (!session && !isLoginPage) {
      router.replace("/studio/login")
    }
  }, [session, loading, isLoginPage, router])

  // Mostra nada enquanto verifica auth (evita flash)
  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="h-6 w-6 animate-spin rounded-full border-2 border-primary border-t-transparent" />
      </div>
    )
  }

  // Na página de login, renderiza sempre
  if (isLoginPage) return <>{children}</>

  // Nas páginas internas, só renderiza se autenticado
  if (!session) return null

  return <>{children}</>
}

export default function StudioLayout({ children }: { children: React.ReactNode }) {
  return (
    <AuthProvider>
      <AuthGuard>{children}</AuthGuard>
    </AuthProvider>
  )
}
